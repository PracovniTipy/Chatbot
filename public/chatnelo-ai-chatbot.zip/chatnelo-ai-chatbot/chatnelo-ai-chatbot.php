<?php
/**
 * Plugin Name:       Chatnelo – AI Chatbot for WooCommerce
 * Plugin URI:        https://chatbot-production-6b09.up.railway.app/marketing
 * Description:       AI shopping assistant that answers your customers 24/7 using your real products, prices, stock and shipping rules. Shows clickable product cards and replies in the customer's language.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            BrosWars Studio
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       chatnelo-ai-chatbot
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CHATNELO_SERVICE_URL', 'https://chatbot-production-6b09.up.railway.app' );

/* ---------------------------------------------------------------- settings */

function chatnelo_default_options() {
	return array(
		'store_id'   => '',
		'widget_key' => '',
		'color'      => '#312e81',
		'position'   => 'right',
		'title'      => '',
		'greeting'   => '',
	);
}

function chatnelo_options() {
	return wp_parse_args( get_option( 'chatnelo_options', array() ), chatnelo_default_options() );
}

add_action( 'admin_menu', function () {
	add_options_page( 'Chatnelo', 'Chatnelo AI Chatbot', 'manage_options', 'chatnelo', 'chatnelo_settings_page' );
} );

add_action( 'admin_init', function () {
	register_setting( 'chatnelo', 'chatnelo_options', array(
		'type'              => 'array',
		'sanitize_callback' => 'chatnelo_sanitize_options',
		'default'           => chatnelo_default_options(),
	) );
} );

function chatnelo_sanitize_options( $input ) {
	$clean = chatnelo_default_options();
	$input = is_array( $input ) ? $input : array();
	$clean['store_id']   = preg_replace( '/[^a-f0-9\-]/i', '', (string) ( $input['store_id'] ?? '' ) );
	$clean['widget_key'] = preg_replace( '/[^a-f0-9]/i', '', (string) ( $input['widget_key'] ?? '' ) );
	$color               = sanitize_hex_color( $input['color'] ?? '' );
	$clean['color']      = $color ? $color : '#312e81';
	$clean['position']   = ( ( $input['position'] ?? '' ) === 'left' ) ? 'left' : 'right';
	$clean['title']      = sanitize_text_field( $input['title'] ?? '' );
	$clean['greeting']   = sanitize_text_field( $input['greeting'] ?? '' );
	return $clean;
}

function chatnelo_feed_url() {
	return rest_url( 'chatnelo/v1/feed' );
}

function chatnelo_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}
	$o = chatnelo_options();
	?>
	<div class="wrap">
		<h1>Chatnelo – AI Chatbot</h1>
		<ol>
			<li><?php
				printf(
					/* translators: %s: dashboard link */
					esc_html__( 'Create a free account in the %s and copy your Store ID and widget key (data-key) here.', 'chatnelo-ai-chatbot' ),
					'<a href="' . esc_url( CHATNELO_SERVICE_URL . '/store/dashboard' ) . '" target="_blank" rel="noopener">Chatnelo dashboard</a>'
				); ?></li>
			<li><?php esc_html_e( 'In the Chatnelo dashboard, paste this product feed URL and click "Load products from feed". Your products, prices and stock then sync automatically every 6 hours:', 'chatnelo-ai-chatbot' ); ?>
				<br><input type="text" readonly class="large-text code" value="<?php echo esc_attr( chatnelo_feed_url() ); ?>" onclick="this.select()"></li>
			<li><?php esc_html_e( 'Save the settings below – the chat bubble appears on your store.', 'chatnelo-ai-chatbot' ); ?></li>
		</ol>
		<form method="post" action="options.php">
			<?php settings_fields( 'chatnelo' ); ?>
			<table class="form-table" role="presentation">
				<tr><th scope="row"><label for="chatnelo_store_id">Store ID</label></th>
					<td><input name="chatnelo_options[store_id]" id="chatnelo_store_id" type="text" class="regular-text code" value="<?php echo esc_attr( $o['store_id'] ); ?>"></td></tr>
				<tr><th scope="row"><label for="chatnelo_widget_key"><?php esc_html_e( 'Widget key', 'chatnelo-ai-chatbot' ); ?></label></th>
					<td><input name="chatnelo_options[widget_key]" id="chatnelo_widget_key" type="text" class="regular-text code" value="<?php echo esc_attr( $o['widget_key'] ); ?>"></td></tr>
				<tr><th scope="row"><label for="chatnelo_color"><?php esc_html_e( 'Brand color', 'chatnelo-ai-chatbot' ); ?></label></th>
					<td><input name="chatnelo_options[color]" id="chatnelo_color" type="color" value="<?php echo esc_attr( $o['color'] ); ?>"></td></tr>
				<tr><th scope="row"><?php esc_html_e( 'Position', 'chatnelo-ai-chatbot' ); ?></th>
					<td><select name="chatnelo_options[position]">
						<option value="right" <?php selected( $o['position'], 'right' ); ?>><?php esc_html_e( 'Bottom right', 'chatnelo-ai-chatbot' ); ?></option>
						<option value="left" <?php selected( $o['position'], 'left' ); ?>><?php esc_html_e( 'Bottom left', 'chatnelo-ai-chatbot' ); ?></option>
					</select></td></tr>
				<tr><th scope="row"><label for="chatnelo_title"><?php esc_html_e( 'Chat title (optional)', 'chatnelo-ai-chatbot' ); ?></label></th>
					<td><input name="chatnelo_options[title]" id="chatnelo_title" type="text" class="regular-text" value="<?php echo esc_attr( $o['title'] ); ?>"></td></tr>
				<tr><th scope="row"><label for="chatnelo_greeting"><?php esc_html_e( 'Greeting (optional)', 'chatnelo-ai-chatbot' ); ?></label></th>
					<td><input name="chatnelo_options[greeting]" id="chatnelo_greeting" type="text" class="large-text" value="<?php echo esc_attr( $o['greeting'] ); ?>"></td></tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( admin_url( 'options-general.php?page=chatnelo' ) ) . '">' . esc_html__( 'Settings', 'chatnelo-ai-chatbot' ) . '</a>' );
	return $links;
} );

/* ------------------------------------------------------------ chat widget */

add_action( 'wp_enqueue_scripts', function () {
	$o = chatnelo_options();
	if ( '' === $o['store_id'] || '' === $o['widget_key'] || is_admin() ) {
		return;
	}
	wp_enqueue_script( 'chatnelo-widget', CHATNELO_SERVICE_URL . '/embed.js', array(), '1.0.0', array( 'in_footer' => true, 'strategy' => 'async' ) );
} );

add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( 'chatnelo-widget' !== $handle ) {
		return $tag;
	}
	$o     = chatnelo_options();
	$attrs = array(
		'data-store'    => $o['store_id'],
		'data-key'      => $o['widget_key'],
		'data-color'    => $o['color'],
		'data-position' => $o['position'],
	);
	if ( '' !== $o['title'] ) {
		$attrs['data-title'] = $o['title'];
	}
	if ( '' !== $o['greeting'] ) {
		$attrs['data-greeting'] = $o['greeting'];
	}
	$extra = '';
	foreach ( $attrs as $name => $value ) {
		$extra .= ' ' . $name . '="' . esc_attr( $value ) . '"';
	}
	return str_replace( ' src=', $extra . ' src=', $tag );
}, 10, 2 );

/* ----------------------------------------------------------- product feed */

add_action( 'rest_api_init', function () {
	register_rest_route( 'chatnelo/v1', '/feed', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => 'chatnelo_render_feed',
	) );
} );

function chatnelo_xml( $text ) {
	return htmlspecialchars( wp_strip_all_tags( (string) $text ), ENT_XML1 | ENT_QUOTES, 'UTF-8' );
}

function chatnelo_render_feed() {
	if ( ! function_exists( 'wc_get_products' ) ) {
		return new WP_Error( 'chatnelo_no_woocommerce', 'WooCommerce is not active.', array( 'status' => 503 ) );
	}
	$currency = get_woocommerce_currency();
	$products = wc_get_products( array(
		'status'     => 'publish',
		'visibility' => 'catalog',
		'limit'      => 5000,
		'orderby'    => 'date',
		'order'      => 'DESC',
	) );
	$out  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
	$out .= '<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0"><channel>';
	$out .= '<title>' . chatnelo_xml( get_bloginfo( 'name' ) ) . '</title>';
	foreach ( $products as $product ) {
		$price = wc_get_price_including_tax( $product );
		$image = wp_get_attachment_image_url( $product->get_image_id(), 'woocommerce_thumbnail' );
		$terms = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );
		$out  .= '<item>';
		$out  .= '<g:id>' . chatnelo_xml( $product->get_id() ) . '</g:id>';
		$out  .= '<title>' . chatnelo_xml( $product->get_name() ) . '</title>';
		$out  .= '<g:description>' . chatnelo_xml( wp_trim_words( $product->get_short_description() ? $product->get_short_description() : $product->get_description(), 80 ) ) . '</g:description>';
		$out  .= '<link>' . esc_url( $product->get_permalink() ) . '</link>';
		if ( $image ) {
			$out .= '<g:image_link>' . esc_url( $image ) . '</g:image_link>';
		}
		$out .= '<g:price>' . chatnelo_xml( wc_format_decimal( $price, 2 ) . ' ' . $currency ) . '</g:price>';
		$out .= '<g:availability>' . ( $product->is_in_stock() ? 'in stock' : 'out of stock' ) . '</g:availability>';
		if ( ! is_wp_error( $terms ) && $terms ) {
			$out .= '<g:product_type>' . chatnelo_xml( implode( ' > ', $terms ) ) . '</g:product_type>';
		}
		$out .= '</item>';
	}
	$out .= '</channel></rss>';

	$response = new WP_REST_Response();
	$response->set_status( 200 );
	$response->header( 'Content-Type', 'application/xml; charset=UTF-8' );
	add_filter( 'rest_pre_serve_request', function ( $served, $result ) use ( $out ) {
		if ( $result->get_matched_route() === '/chatnelo/v1/feed' ) {
			echo $out; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- XML built from escaped parts above.
			return true;
		}
		return $served;
	}, 10, 2 );
	return $response;
}
