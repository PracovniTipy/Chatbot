=== Chatnelo – AI Chatbot for WooCommerce ===
Contributors: chatnelo
Tags: chatbot, ai, woocommerce, live chat, customer support
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI shopping assistant that answers your customers 24/7 from your real products, prices, stock and shipping rules.

== Description ==

Chatnelo adds an AI chat bubble to your WooCommerce store. It answers questions like "Is this in stock?", "How much is shipping?" or "Any gift ideas under $50?" using only your store's real data, shows clickable product cards that lead straight to the product page and replies in the customer's language.

* Answers 24/7 from your products, prices and stock
* Clickable product cards in the chat
* Replies in English, German, Spanish, Czech, Polish and more
* Your brand color and position
* No coding – the plugin adds the chat and publishes a product feed for you

= External service =

This plugin connects to the Chatnelo service (https://chatbot-production-6b09.up.railway.app) to show the chat widget and generate answers.

* The chat widget script is loaded from the Chatnelo service on your storefront.
* Messages typed by your visitors are sent to the Chatnelo service, which uses OpenAI to generate the answer. Chatnelo does not store message content, only a count of conversations for billing.
* The plugin publishes a public product feed at /wp-json/chatnelo/v1/feed (product name, description, price, stock status, link, image and category – the same data shown in your store). The Chatnelo service downloads it to answer product questions.

Privacy policy: https://chatbot-production-6b09.up.railway.app/privacy
Pricing: https://chatbot-production-6b09.up.railway.app/marketing

== Installation ==

1. Install and activate the plugin.
2. Create a free account in the Chatnelo dashboard (link in Settings → Chatnelo AI Chatbot).
3. Copy your Store ID and widget key into the plugin settings and save.
4. Paste the product feed URL shown in the plugin settings into the Chatnelo dashboard and click "Load products from feed".

== Frequently Asked Questions ==

= Do I need to code anything? =
No. The plugin adds the chat and the product feed automatically.

= Which languages does it speak? =
It replies in the language the customer writes in.

== Changelog ==

= 1.0.0 =
* First release.
